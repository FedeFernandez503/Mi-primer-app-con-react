import React from "react";

function Cuerpo(props) {
    return (
        <div>
            <main>
                <h1>Pricing</h1>
                <p id="ParrafoGrande">Quickly build an effective pricing table for your potential customers with this layout. 
                It's built with default Material-UI components with little customization.</p>
            </main>
            <main id="MenuTarjetas">
                <div className="Tarjeta">
                    <div className="Encabezados">
                        <span>{props.tarjeta.titulo1}</span>
                    </div>
                    <div className="Precio">
                    <h2>{props.tarjeta.numero1}</h2>
                        <h6>/mo</h6>
                    </div>
                    <div className="Texto">
                        <ul>
                            <li>10 users included</li>
                            <li>2 GB of storage</li>
                            <li>Help center access</li>
                            <li>Email support</li>
                        </ul>
                    </div>
                    <div className="Botones">
                        <button>SING UP FOR FREE</button>
                    </div>
                </div>
                <div className="Tarjeta">
                    <div className="Encabezados">
                        <span>{props.tarjeta.titulo2}</span>
                    </div>
                    <div id="CuerpoTarjeta">
                        <div className="Precio">
                        <h2>{props.tarjeta.numero2}</h2>
                            <h6>/mo</h6>
                        </div>
                            <ul>
                                <li>10 users included</li>
                                <li>2 GB of storage</li>
                                <li>Help center access</li>
                                <li>Email support</li>
                            </ul>
                    </div>
                <div className="Botones">
                    <button>SING UP FOR FREE</button>
                    </div>
                </div>
                <div className="Tarjeta">
                    <div className="Encabezados">
                        <span>{props.tarjeta.titulo3}</span>
                    </div>
                    <div className="Precio">
                    <h2>{props.tarjeta.numero3}</h2>
                        <h6>/mo</h6>
                    </div>
                    <div className="Texto">
                        <ul>
                            <li>10 users included</li>
                            <li>2 GB of storage</li>
                            <li>Help center access</li>
                            <li>Email support</li>
                        </ul>
                    </div>
                    <div className="Botones">
                        <button>SING UP FOR FREE</button>
                    </div>
                </div>
            </main>
        </div>    
    )
    
}

export default Cuerpo;