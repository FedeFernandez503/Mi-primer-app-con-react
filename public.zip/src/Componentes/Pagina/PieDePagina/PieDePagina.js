import React from "react";

function Final(props) {
    return (
        <footer>
            <div id="Conjuntos">
                <div className="Conjunto">
                    <h6 className="a">Company</h6>
                    <ul className="ul">
                        <li className="alineacion">Team</li>
                        <li className="alineacion">History</li>
                        <li className="alineacion">Contact us</li>
                        <li className="alineacion">Locations</li>
                    </ul>
                </div> 
                <div className="Conjunto">
                    <h6 className="a">Features</h6>
                    <ul className="ul">
                        <li className="alineacion">Cool stuff</li>
                        <li className="alineacion">Random feature</li>
                        <li className="alineacion">Team feature</li>
                        <li className="alineacion">Developer stuff</li>
                        <li className="alineacion">Another one</li>
                    </ul>
                </div>   
                <div className="Conjunto">
                    <h6 className="a">Resources</h6>
                    <ul className="ul">
                        <li className="alineacion">Resource</li>
                        <li className="alineacion">Resource name</li>
                        <li className="alineacion">Another resource</li>
                        <li className="alineacion">Final resource</li>
                    </ul>
                </div>   
                <div className="Conjunto">
                    <h6 className="a">Legal</h6>
                    <ul className="ul">
                        <li className="alineacion">Privacy policy</li>
                        <li className="alineacion">Terms of use</li>
                    </ul>
                </div>                      
            </div>   
            <p>Copyright © <a href="https://material-ui.com/">Your Website</a> 2021.</p>
        </footer>
    )
    
}

export default Final;