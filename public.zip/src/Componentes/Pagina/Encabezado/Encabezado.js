import React from "react";

function Encabezado(props) {
    return (  
        <div className="Header">
            <div id="Contenedor">
                <h3 id="Titulo">Company name</h3>
                <div id="Menu">
                    <h4>{props.menu.Nombre1}</h4>
                    <h4>{props.menu.Nombre2}</h4>
                    <h4>{props.menu.Nombre3}</h4>
                    <button>{props.menu.Nombre4}</button>
                </div>
            </div>
        </div>
    )   
}      
export default Encabezado;