import React from "react";

function TituloTarjeta(props) {
    return (
        <div>
            <span>{props.tarjeta.titulo}</span>
            
        </div>
    )
    
}

export default TituloTarjeta;