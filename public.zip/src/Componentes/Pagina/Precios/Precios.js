import React from "react";

function Precio(props) {
    return (
        <div>
            <h2>{props.precio.numero}</h2>
        </div>
    )
    
}

export default Precio;