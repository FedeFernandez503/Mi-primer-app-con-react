
import "./Pagina.css";
import Final from "./PieDePagina/PieDePagina";
import Encabezado from "./Encabezado/Encabezado";
import Cuerpo from "./Cuerpo/Cuerpo";

const menu1 = {
    Nombre1: 'FEATURES',  
    Nombre2: 'ENTERPRISE',  
    Nombre3: 'SUPPORT',  
    Nombre4: 'LOGIN',  
  }

 
  const tarjeta1 = {
    titulo1: 'Free',  
    titulo2: 'Pro',  
    titulo3: 'Enterprise',
    numero1: '$0',  
    numero2: '$15',  
    numero3: '$30',    
  }

 

function Principal(props) {
    return (
        <div id="pagina">
            <Encabezado menu={menu1} />
            <Cuerpo tarjeta={tarjeta1}/>
            <Final />
        </div>
    )
    
}

export default Principal;
