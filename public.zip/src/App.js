import Principal from  "./Componentes/Pagina/Pagina";


function App() {
  
  

  return (
    <>
      <div className="App">
       <Principal />
       
      </div>
    </>
  );
}

export default App;

